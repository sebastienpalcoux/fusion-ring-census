#pragma once

// The two distributions select this one switch through variant.json.
#ifndef CENSUS_SYMMETRY_REVISION
#define CENSUS_SYMMETRY_REVISION 0
#endif
#if CENSUS_SYMMETRY_REVISION != 0 && CENSUS_SYMMETRY_REVISION != 1
#error "CENSUS_SYMMETRY_REVISION must be zero or one"
#endif

inline constexpr unsigned long long census_symmetry_limit =
    CENSUS_SYMMETRY_REVISION ? 8192ULL : 4096ULL;
