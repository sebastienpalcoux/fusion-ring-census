#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <utility>
#include <vector>

// Reversible bounds propagation of v <= v o p for genuine permutations p.
// Watch only the first pair whose equality is not yet forced. Shrinking a
// domain can affect a constraint only through one of its two watched domains.
template<std::size_t E> class EdgeSymmetryDomains {
public:
    using Domain = std::uint32_t;
    using Permutation = std::array<int,E>;
    struct Mark {std::size_t domains,watches;};
    std::array<Domain,E> domain{};
    unsigned long long checked=0,forced=0,rejected=0;
private:
    const std::vector<Permutation>* maps_=nullptr;
    std::vector<std::array<int,2>> watch_;
    std::array<std::vector<int>,E> listeners_;
    std::vector<std::pair<int,Domain>> domain_trail_;
    struct WatchChange {int id,old_a,old_b,new_a,new_b;};
    std::vector<WatchChange> watch_trail_;
    std::vector<int> queue_;
    std::vector<unsigned char> queued_;
    static int low(Domain d){return __builtin_ctz(d);}
    static int high(Domain d){return 31-__builtin_clz(d);}
    static bool single(Domain d){return !(d&(d-1));}
    void clear_queue(){
        for(int id:queue_)queued_[id]=0;
        queue_.clear();
    }
    void set_watch(int id,int a,int b){
        const auto old=watch_[id];
        if(old[0]==a&&old[1]==b)return;
        watch_trail_.push_back({id,old[0],old[1],a,b});
        watch_[id]={a,b};
        if(a>=0)listeners_[a].push_back(id);
        if(b>=0&&b!=a)listeners_[b].push_back(id);
    }
    bool reduce(int v,Domain keep,bool inference){
        keep &= domain[v];
        if(!keep)return false;
        if(keep==domain[v])return true;
        domain_trail_.emplace_back(v,domain[v]);
        if(inference)forced+=__builtin_popcount(domain[v])-__builtin_popcount(keep);
        domain[v]=keep;
        for(int id:listeners_[v]){
            const auto w=watch_[id];
            if((w[0]==v||w[1]==v)&&!queued_[id]){
                queued_[id]=1;queue_.push_back(id);
            }
        }
        return true;
    }
    bool process(int id){
        ++checked;
        const auto& p=(*maps_)[id];
        for(int k=0;k<int(E);++k){
            int j=p[k];if(j==k)continue;
            Domain a=domain[k],b=domain[j];
            if(low(a)>high(b))return false;
            if(high(a)<low(b)){set_watch(id,-1,-1);return true;}
            if(single(a)&&a==b)continue;
            set_watch(id,k,j);
            Domain left=a&((Domain(1)<<(high(b)+1))-1);
            Domain right=b&~((Domain(1)<<low(a))-1);
            return reduce(k,left,true)&&reduce(j,right,true);
        }
        set_watch(id,-1,-1);return true;
    }
public:
    void reset(const std::vector<Permutation>& maps,int bound){
        maps_=&maps;domain.fill((Domain(1)<<(bound+1))-1);
        for(auto& list:listeners_)list.clear();
        domain_trail_.clear();watch_trail_.clear();queue_.clear();
        watch_.assign(maps.size(),{-1,-1});queued_.assign(maps.size(),0);
        for(std::size_t id=0;id<maps.size();++id){
            for(int k=0;k<int(E);++k)if(maps[id][k]!=k){
                int j=maps[id][k];watch_[id]={k,j};
                listeners_[k].push_back(int(id));listeners_[j].push_back(int(id));
                break;
            }
        }
    }
    Mark mark()const{return {domain_trail_.size(),watch_trail_.size()};}
    void restore(Mark m){
        clear_queue();
        while(watch_trail_.size()>m.watches){
            auto t=watch_trail_.back();watch_trail_.pop_back();
            if(t.new_a>=0)listeners_[t.new_a].pop_back();
            if(t.new_b>=0&&t.new_b!=t.new_a)listeners_[t.new_b].pop_back();
            watch_[t.id]={t.old_a,t.old_b};
        }
        while(domain_trail_.size()>m.domains){
            auto t=domain_trail_.back();domain_trail_.pop_back();domain[t.first]=t.second;
        }
    }
    bool assign(int v,int value){
        clear_queue();
        if(!reduce(v,Domain(1)<<value,false)){++rejected;return false;}
        for(std::size_t at=0;at<queue_.size();++at){
            int id=queue_[at];queued_[id]=0;
            if(!process(id)){++rejected;clear_queue();return false;}
        }
        clear_queue();return true;
    }
};
