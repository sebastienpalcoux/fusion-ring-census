#include "../code/symmetry_domains.hpp"
#include <algorithm>
#include <iostream>
#include <numeric>
#include <random>
#include <set>
#include <stdexcept>

template<std::size_t E> void audit(int bound,int cases,std::mt19937& rng){
    using State=EdgeSymmetryDomains<E>;
    using Vector=std::array<int,E>;
    for(int trial=0;trial<cases;++trial){
        std::vector<Vector> maps;
        Vector p;std::iota(p.begin(),p.end(),0);
        if(trial==0){do{maps.push_back(p);}while(std::next_permutation(p.begin(),p.end()));}
        else for(int j=0;j<1+int(rng()%24);++j){std::shuffle(p.begin(),p.end(),rng);maps.push_back(p);}
        std::set<Vector> expected,actual;
        Vector v{};
        auto brute=[&](auto&& self,int k)->void{
            if(k<int(E)){for(int x=0;x<=bound;++x){v[k]=x;self(self,k+1);}return;}
            for(const auto& q:maps){Vector image;for(int i=0;i<int(E);++i)image[i]=v[q[i]];if(image<v)return;}
            expected.insert(v);
        };brute(brute,0);
        State state;state.reset(maps,bound);
        Vector order;std::iota(order.begin(),order.end(),0);
        if(trial%2)std::shuffle(order.begin(),order.end(),rng);
        auto visit=[&](auto&& self,int at)->void{
            if(at==int(E)){actual.insert(v);return;}
            int k=order[at];auto before=state.domain;
            for(int x=0;x<=bound;++x){
                auto mark=state.mark();v[k]=x;
                if(state.assign(k,x)){
                    // Every satisfying completion of this branch must remain
                    // inside the propagated domains (checked by brute force).
                    for(const auto& solution:expected){
                        bool agrees=true;for(int j=0;j<=at;++j)agrees&=solution[order[j]]==v[order[j]];
                        if(agrees)for(int j=0;j<int(E);++j)
                            if(!(state.domain[j]&(1u<<solution[j])))throw std::runtime_error("lost satisfying completion");
                    }
                    self(self,at+1);
                }
                state.restore(mark);
                if(state.domain!=before)throw std::runtime_error("domain rollback mismatch");
            }
        };visit(visit,0);
        if(actual!=expected)throw std::runtime_error("enumeration disagrees with independent brute force");
    }
    std::cout<<"PASS variables "<<E<<" bound "<<bound<<" cases "<<cases<<'\n';
}

template<std::size_t E> void audit_large(std::mt19937& rng){
    using State=EdgeSymmetryDomains<E>;
    using Vector=std::array<int,E>;
    for(int trial=0;trial<100;++trial){
        std::vector<Vector> maps;Vector id;std::iota(id.begin(),id.end(),0);
        // A genuine two-element group, acting on many coefficients.
        auto p=id;for(int i=0;i<int(E)/2;++i)std::swap(p[i],p[E-1-i]);maps={id,p};
        Vector v;for(int& x:v)x=rng()%16;
        Vector image;for(int i=0;i<int(E);++i)image[i]=v[p[i]];v=std::min(v,image);
        State state;state.reset(maps,15);auto initial=state.mark();
        for(int i=0;i<int(E);++i){
            if(!state.assign(i,v[i]))throw std::runtime_error("lost known high-rank canonical vector");
            for(int j=0;j<int(E);++j)if(!(state.domain[j]&(1u<<v[j])))throw std::runtime_error("unsafe high-rank bound");
        }
        state.restore(initial);for(auto d:state.domain)if(d!=65535)throw std::runtime_error("high-rank rollback");
    }
    std::cout<<"PASS high-rank variables "<<E<<" bound 15 cases 100\n";
}
int main(){
    std::mt19937 rng(20261023);
    audit<5>(1,100,rng);audit<5>(2,60,rng);audit<4>(3,40,rng);
    audit<3>(15,8,rng);audit_large<45>(rng);audit_large<55>(rng);
    std::cout<<"All independent symmetry-domain audits passed.\n";
}
