#define main census_main_not_used
#include "../code/enumerate_selfdual_fast.cpp"
#undef main
#include <map>
#include <memory>
#include <sstream>

template<int N> void prefix_check(const std::string& system,const std::vector<int>&v){
    Worker<N> worker(system.c_str(),1);
    for(int i=0;i<N;++i){worker.u[i]=v[i];worker.Q[i][i]=v[N+i];}
    for(int k=0;k<worker.E;++k){auto edge=worker.edge[k];worker.Q[edge.first][edge.second]=worker.Q[edge.second][edge.first]=v[2*N+k];}
    worker.prepare_stabilizers();
    for(int filled=0;filled<=worker.E;++filled)if(!worker.canonical_edges(filled))throw std::runtime_error("lost reference first-matrix prefix");
#if CENSUS_SYMMETRY_REVISION
    for(int k=0;k<worker.E;++k){
        if(!worker.symmetry_domains.assign(k,v[2*N+k]))throw std::runtime_error("lost reference under revised symmetry");
        for(int j=k+1;j<worker.E;++j)if(!(worker.symmetry_domains.domain[j]&(1u<<v[2*N+j])))throw std::runtime_error("lost reference future edge");
    }
#endif
}

int main(int argc,char**argv){
    if(argc!=3)return 2;
    system_dir=argv[1];allowance=1e9;began=Clock::now();
    std::ifstream input(argv[2]);std::string line;
    if(!input)throw std::runtime_error("reference input not found");
    std::map<std::pair<int,int>,std::unique_ptr<CompletionSolver>> solvers;
    int checked=0,canonical_checked=0;
    while(std::getline(input,line)){
        std::istringstream row(line);int rank,canonical,pairs;row>>rank>>canonical>>pairs;
        std::vector<int> v;int value;while(row>>value)v.push_back(value);
        auto key=std::make_pair(rank,pairs);
        std::string path=system_dir+"/"+(pairs?"rank"+std::to_string(rank)+"_pairs"+std::to_string(pairs)+".txt":"system"+std::to_string(rank)+"sd.txt");
        if(!solvers.count(key))solvers[key]=std::make_unique<CompletionSolver>(path.c_str(),1,1e9,began);
        auto& solver=*solvers[key];
        if(int(v.size())!=solver.nv)throw std::runtime_error("wrong reference dimension");
        for(int i=0;i<solver.nv;++i)solver.dom[i]=1u<<v[i];
        for(const auto& e:solver.eqs)if(solver.exact(e))throw std::runtime_error("reference fails exact equations");
        if(canonical){
            if(!solver.canonical_complete(v))throw std::runtime_error("reference fails full canonicality");
            if(!pairs){
                if(rank==9)prefix_check<7>(path,v);
                if(rank==10)prefix_check<8>(path,v);
                if(rank==11)prefix_check<9>(path,v);
            }
            ++canonical_checked;
        }
        ++checked;
    }
    if(!checked)throw std::runtime_error("reference input is empty");
    std::cout<<"PASS reference/fixture rows "<<checked<<" full canonicality checks "<<canonical_checked<<'\n';
}
