#define main census_main_not_used
#include "../code/enumerate_selfdual_fast.cpp"
#undef main
#include <stdexcept>

template<int N> void worker_load(const std::string& directory){
    for(int bound:{1,15})for(int weight:{1,2}){
        std::string path=directory+"/system"+std::to_string(N+2)+"sd.txt";
        Worker<N> worker(path.c_str(),bound,weight);
        worker.prepare_stabilizers();
        if(worker.row_masks.size()!=std::size_t(N)*(bound+1)*N*(N*bound*bound+1))throw std::runtime_error("row-mask allocation");
        if(worker.dot_masks.size()!=std::size_t(N*(N-1)/2)*(bound+1)*((N+1)*bound*bound+1))throw std::runtime_error("dot-mask allocation");
        std::vector<int> constant(worker.csp.nv,bound);
        if(!worker.csp.canonical_complete(constant)||worker.csp.canonicalize(constant)!=constant)throw std::runtime_error("constant-vector canonicality");
        std::cout<<"PASS worker rank "<<N+2<<" bound "<<bound<<" weight "<<weight<<'\n';
    }
}

int main(int argc,char** argv){
    if(argc!=2)return 2;
    system_dir=argv[1];allowance=1e9;began=Clock::now();
    for(int rank:{12,13})for(int pairs=0;pairs<=(rank-1)/2;++pairs)for(int bound:{1,15}){
        std::string name=pairs?"rank"+std::to_string(rank)+"_pairs"+std::to_string(pairs)+".txt":"system"+std::to_string(rank)+"sd.txt";
        CompletionSolver solver((system_dir+"/"+name).c_str(),bound,1e9,began);
        if(solver.rank_!=rank||solver.pairs_!=pairs||solver.nv>512)throw std::runtime_error("wrong high-rank system");
        std::cout<<"PASS system rank "<<rank<<" pairs "<<pairs<<" bound "<<bound<<" variables "<<solver.nv<<'\n';
    }
    worker_load<10>(system_dir);worker_load<11>(system_dir);
    std::cout<<"All rank12/13 loading and maximum-bound allocation checks passed.\n";
}
