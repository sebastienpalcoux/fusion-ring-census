#!/usr/bin/env python3
"""Compile and run finite high-rank audits for both symmetry settings."""
import argparse
import gzip
import os
from pathlib import Path
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--references',action='store_true',help='Also check all recorded rank9--11 parameter vectors')
    ap.add_argument('--logs',type=Path,help='Optional directory for audit/compilation logs')
    a=ap.parse_args()
    if a.logs:a.logs.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='fusion-rank13-audits-') as td:
        td=Path(td)
        reference=td/'reference.txt'
        if a.references:
            reference.write_bytes(gzip.open(ROOT/'audits/data/reference_parameters_rank9_13.txt.gz','rb').read())
        cases=[('audit_symmetry_domains.cpp',[],0),('audit_identity_rank13.cpp',[],0)]
        for revision in (0,1):
            cases.extend([('audit_rank13_loading.cpp',[str(ROOT/'systems')],revision),
                          ('audit_rank13_graph.cpp',[str(ROOT/'systems')],revision)])
            if a.references:cases.append(('audit_reference_parameters.cpp',[str(ROOT/'systems'),str(reference)],revision))
        for filename,arguments,revision in cases:
            tag=Path(filename).stem+('_revised' if revision else '_baseline')
            binary=td/tag
            command=[os.environ.get('CXX','g++'),'-O2','-std=c++17','-fopenmp',
                     '-DCENSUS_SELFDUAL_RANK=4',f'-DCENSUS_SYMMETRY_REVISION={revision}',
                     str(ROOT/'audits'/filename),'-o',str(binary)]
            compile_run=subprocess.run(command,capture_output=True)
            if a.logs:(a.logs/(tag+'.compile.log')).write_bytes(compile_run.stdout+compile_run.stderr)
            if compile_run.returncode:
                raise RuntimeError(compile_run.stderr.decode(errors='replace'))
            result=subprocess.run([str(binary),*arguments],capture_output=True)
            if a.logs:(a.logs/(tag+'.log')).write_bytes(result.stdout+result.stderr)
            print(result.stdout.decode(),end='',flush=True)
            if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
    print('All rank-13 finite audits passed for both policies.')

if __name__=='__main__':main()
