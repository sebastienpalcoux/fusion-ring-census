# Rank-13 extension and controlled symmetry revision

## Scope of the comparison

Both distributions have exactly the same source and equation files. The sole
configuration difference is the boolean `symmetry_revision` in `variant.json`.
It becomes the compile-time definition `CENSUS_SYMMETRY_REVISION=0` or `1`.
The binary build signature includes that definition; execution reports also
record the setting and a configuration-specific algorithm hash.

Both variants include the common rank-13 guards, systems, arithmetic limits,
strict C++17 capture fix, constant-vector canonicality shortcut and atomic stream
capture. The baseline retains the previous symmetry policy. The revised build:

1. Raises the maximum fully materialized small symmetry group from 4096 to 8192.
2. Replaces repeated scans of self-dual edge comparisons by reversible watched
   domain propagation, including necessary bounds on unassigned edges.

The cutoff remains bounded: neither variant materializes a factorial table for
the largest high-rank groups. Increased comparison work may outweigh pruning;
the revised version is not assumed to be faster.

## Exact domain reductions

Let x be the ordered vector of strict-upper-triangular first-matrix entries.
Every stored permutation p is induced by an actual permutation of tail labels
preserving the already fixed colors (u_i, Q_ii). A canonical vector must satisfy
x <= x composed with p lexicographically for each such p.

Skip positions with p(k)=k. Also skip positions where both coefficient domains
are the same singleton: their equality is then forced throughout the domain box.
At the first remaining position k, put a=x_k and b=x_p(k).

- If min(a)>max(b), every completion violates the required inequality.
- If max(a)<min(b), every completion satisfies it, independently of later entries.
- Otherwise the necessary condition a<=b permits removing values of a above
  max(b), and values of b below min(a).

The last step is only a necessary bounds reduction. It does not assume that
equal domains mean equal coefficients. Domains with holes remain exact bitmasks.
A domain becoming a singleton may force equality and permit advancing to a later
position. These operations therefore cannot discard a canonical completion.

## Watching and rollback

Each active comparison watches its first unresolved pair of domains. Earlier
positions are identities or forced singleton equalities, so shrinking any other
domain cannot change their status. Later positions cannot decide this comparison
until the watched pair becomes equal. A comparison already separated in the
correct direction stays satisfied under any further domain reduction.

A changed domain therefore queues only comparisons currently watching it.
Processing continues until the queue is empty or a contradiction appears.
Listener lists may contain historical entries; current watch positions filter
those entries. Domain changes, watch changes and listener registrations have
reversible trails. Before trying a sibling branch, all are restored to the
parent fixed point, and the queue is cleared. No information specific to a
rejected branch survives rollback.

The independent finite audit compares complete enumeration against brute-force
lex inequalities, checks retained completions inside every propagated box, uses
arbitrary assignment orders and exercises repeated rollback at bounds through
15. Actual graph audits separately verify the induced edge maps and real
first-matrix prefixes, including the supplied rank-11 examples.

## Exact final acceptance

For small color groups, the comparison table contains every group element.
For large groups, stored swaps and products are only a necessary subset; the
existing exact colored-graph canonicality check still runs at a completed matrix.
The completion solver's full duality-preserving canonicality test still runs
before emitting a ring. The revision changes necessary pruning and its
implementation, not the required final canonical representative.

A vector whose entries are all equal is invariant under every coefficient
permutation. Both variants return it immediately from the canonicality routines.
This common shortcut avoids a factorial traversal for a trivial invariant vector.

## Extension through rank 13

The self-dual templates now include N=10,11, corresponding to ranks 12,13.
All duality types have generated exact associativity systems. The largest
rank-13 system has 364 coefficient variables and 2643 distinct equations, within
the revised common safety caps of 512 and 8192. Export and launch routing cover
ranks 3 through 13. Weighted folding finds the required lower-rank systems in
the same distribution.

The duality-centralizer group on nonunit labels can have order 12!=479001600
at rank 13; it remains represented compactly. For first-matrix symmetry, the
largest tail stabilizer has order 11!=39916800. In its large-group path the
existing swaps/product subset stores at most 55+binomial(55,2)=1540 edge maps.
The full canonicality tests still have exponential worst-case time.

## Arithmetic and indexing limits

For N<=11, M<=15, C in {1,2}:

- Masks contain the values 0 through M, so every shift is by at most 16.
- The largest row table has N^2(M+1)(NM^2+1)=4793536 entries. The largest dot
  table has binomial(N,2)(M+1)((N+1)M^2+1)=2376880 entries. Index products fit
  signed 32-bit arithmetic; allocations depend on available memory.
- qnorm, qu and unorm are at most NM^2=2475. A witness coefficient has absolute
  value at most 2M^2=450. Bounding all terms and all remaining edge updates gives
  a witness residual below 600000 in absolute value, and cumulative edge bounds
  at most 371250. Their signed 32-bit storage remains sufficient.
- The modular filters use P=17 or 257, both greater than M. A sum of N products
  of residues is at most 11*256^2=720896. Mixed coefficient/residue sums are
  smaller. The offsets (N+2)P^2 and NP^2 still dominate the corresponding
  subtractions before reduction; elimination values and products fit int32.
- The fourth-degree identities and general polynomial evaluations retain
  signed 64-bit arithmetic. The extended direct-identity audit checks all ranks
  through 13 and bounds through 15, in addition to these analytic limits.
- The general solver's modular prime 257 is larger than every coefficient
  domain; the number of variables need not be smaller than that prime.
- The weighted folding trigger requires C=1 and creates C=2, without recursively
  increasing the weight.

These are arithmetic support statements. They do not assert feasible time or
memory for every input. In particular, high multiplicity bounds create many
sorted first-matrix prefixes even before their completion searches begin.

## Verification versus completeness

Both algorithms search equations generated from the axioms. Existing census
counts and recorded multiplication tables are used only after enumeration or in
regression/audit tools. The independent tensor checker verifies axioms and exact
isomorphism witnesses; it alone does not establish exhaustiveness. Completeness
also depends on the necessary-condition proofs and the exhaustive branching
arguments. Independent human review of those arguments remains useful.
