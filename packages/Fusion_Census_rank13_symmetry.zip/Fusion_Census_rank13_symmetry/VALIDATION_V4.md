# Rank-13 baseline/symmetry pair: validation

Both distributions use shared production source SHA-256
`e476d391164652cd3cbcee4ae8ba86cbe534c48a1aec6f594eb23a8d92169233`.
They differ only in the boolean in `variant.json` and its distribution checksum.
The baseline retains the previous symmetry policy; the revised policy adds
watched lexicographic domain propagation to the self-dual first-matrix search
and raises the compact full-group comparison limit from 4096 to 8192.
The exact canonicality checks at emission remain enabled in both policies.

## Complete search comparisons

Each row below is a complete whole-rank enumeration with both policies, followed
by exact tensor validation and isomorphism deduplication. The compressed result
files were decompressed and hashed independently. Both the sorted parameter
records and complete multiplication tensors match byte for byte between the
policies, not just their counts.

| Rank | Maximum multiplicity | Rings through that bound | Exact output match |
| --- | --- | --- | --- |
| 6 | 3 | 577 | Yes |
| 7 | 2 | 362 | Yes |
| 8 | 1 | 96 | Yes |
| 9 | 1 | 142 | Yes |
| 10 | 1 | 194 | Yes |

The per-multiplicity counts, actual data hashes, run reports, independent
verification reports and engine logs are in
`benchmarks/evidence/rank13_comparison/`. The summary is
`complete_output_parity.json`. Ranks 6–8 also match their previously released
mandatory count prefixes. The final release searches used the source hash above
and the final 4096/8192 limits.

These regression searches overlapped other validation work. Their recorded
times are evidence of completed execution, not controlled speed measurements.
Use `scripts/compare_variants.py` on an otherwise idle laptop for a sequential
comparison with equal inputs and thread counts. Compilation is reported
separately. A speedup is not guaranteed: maintaining domains and storing more
symmetry comparisons can cost more time than they save.

## Rank 11 reference and the observed bottleneck

The supplied completed rank-11, multiplicity-one output contains 182 rings.
Its report records 3769.415 seconds of enumeration with eight threads, including
3143.31 seconds in the self-dual stratum (about 83% of enumeration time) and
213,237,383 first matrices there. This directly identifies a large self-dual
search in that run. It does not imply a universal runtime ratio between ranks.

The reference audit checks all 142 rank-9, 194 rank-10 and 182 rank-11 parameter
records against both policies, including full canonicality and retention of the
actual self-dual first-matrix prefixes. There are 518 reference records in total.
These are regression inputs only. The enumerators do not read them to generate
solutions, and no AnyonWiki or AnyonAtlas data is downloaded or imported.

A complete rank-11 search with the new release was not repeated during this
validation. The 182-ring result belongs to the supplied earlier run, not to a
claimed completed run of either new executable.

## Rank 12 and 13 checks

- Generated every duality type: six systems at rank 12 and seven at rank 13,
  including the self-dual systems. Coverage and associativity equations are
  checked. The largest system has 364 variables and 2643 equations.
- Loaded every new system at bounds 1 and 15 with both policies. Instantiated
  the rank-specific self-dual workers at both bounds and both pivot weights,
  checked their maximum-sized table allocations and constant-vector
  canonicality, and compiled the actual rank-12 and rank-13 executables.
- Checked four independently specified examples: the cyclic groups C12 and
  C13, Ising times the Klein four group (rank 12), and SU(2) level 12 (rank 13).
  Their generated parameter vectors satisfy the equation systems; exported
  tensors agree with the defining fusion rules. The independent exact verifier
  finds four distinct associative rings and no duplicates.
- Ran bounded startup probes of the general and self-dual executables at ranks
  12 and 13 for both policies. They correctly report incomplete searches, and
  the driver does not certify or package these partial results. Initialization
  and compilation are outside the requested enumeration budget; the probes are
  not strict wall-clock deadline tests.

No complete rank-12 or rank-13 census, count, or runtime estimate is claimed.
Arithmetic support through bound 15 does not establish practical runtime or
memory feasibility for a full high-bound search.

## Independent finite audits and automated checks

The Python suite passes all 25 tests under each package's default, covering routing, bounds, policy-specific
build caches, wrong-policy rejection, exact exports, incomplete-output gates,
the verifier, and real large-output and timeout subprocesses. The stream tests
check more than 1 MiB of stdout and more than 128 KiB of stderr against exact
expected bytes. Output is streamed to staged files and published atomically.

The user-facing comparison command also passed an end-to-end rank-9/bound-1,
two-thread run from extracted distribution prototypes, using validated warm
binary caches. It ran the packages sequentially, selected opposite policies,
obtained 142 rings from each, matched both actual data hashes, and produced two
verified result ZIPs. Every member of those ZIPs passed its recorded checksum.
The comparison report and archives are included in `launcher_integration/` under
the evidence directory. This short smoke benchmark measured 3.440 versus 3.047
seconds of enumeration (1.129 times); it is not a prediction for rank 11.

The new C++ audit runner passes with the final source and both policies:

| Audit | Coverage |
| --- | --- |
| Symmetry-domain propagation | 208 exhaustive small cases; 200 cases with 45/55 variables at bound 15; arbitrary assignment order and rollback |
| First/second moment identities | 200,000 independent direct associativity cases through rank 13, bounds 1–15, both pivot weights |
| Actual first-matrix symmetry | 5832 matrices, 16,101,477 permutations, 69,552 prefix checks per policy, including rank-12/13 workers |
| Reference retention | 522 reference/fixture rows, including 518 full canonicality checks per policy |
| High-rank loading | All 13 systems at bounds 1 and 15, and eight worker configurations per policy |

The logs are included under `benchmarks/evidence/rank13_comparison/audits/`.
Reproduce with:

```bash
python3 -m unittest discover -s tests -v
python3 audits/run_rank13_audits.py --references
```

Finite tests cannot by themselves establish completeness. The preservation
argument for the symmetry pruning, watcher/rollback invariants, and integer
range bounds is in `methods/RANK13_SYMMETRY_COMPARISON.md`; earlier mathematical
and benchmark records are retained for provenance.

The two extracted distributions can be checked with:

```bash
python3 Fusion_Census_rank13_baseline/scripts/check_pair.py \
  Fusion_Census_rank13_baseline Fusion_Census_rank13_symmetry
```

This checks the actual common-file fingerprint, every distribution checksum,
and the exact two permitted file differences. Build caches and run directories
are local runtime products and are not shipped in either archive.
