#!/usr/bin/env python3
"""Verify two extracted distributions differ only in their symmetry setting."""
import argparse
import hashlib
import json
from pathlib import Path

IGNORE={'__pycache__','build_cache','runs','.git'}
EXCLUDE_FROM_COMMON={'variant.json','SHA256SUMS','PAIRING.json'}

def files(root):
    return {str(p.relative_to(root)):p for p in root.rglob('*')
            if p.is_file() and not any(part in IGNORE for part in p.relative_to(root).parts)
            and p.suffix not in ('.pyc','.next')}

def common_digest(items):
    h=hashlib.sha256()
    for name,path in sorted(items.items()):
        if name not in EXCLUDE_FROM_COMMON:
            h.update(name.encode());h.update(b'\0');h.update(path.read_bytes())
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('baseline',type=Path);ap.add_argument('revised',type=Path)
    a=ap.parse_args();roots=[a.baseline.resolve(),a.revised.resolve()]
    inventories=[files(root) for root in roots]
    if set(inventories[0])!=set(inventories[1]):ap.error('different file inventories')
    differences={name for name in inventories[0] if inventories[0][name].read_bytes()!=inventories[1][name].read_bytes()}
    if differences!={'variant.json','SHA256SUMS'}:ap.error('unexpected differences: '+', '.join(sorted(differences)))
    for index,(root,items) in enumerate(zip(roots,inventories)):
        value=json.loads((root/'variant.json').read_text())
        if not isinstance(value,dict) or set(value)!={'symmetry_revision'} or type(value['symmetry_revision']) is not bool or value['symmetry_revision'] is not bool(index):
            ap.error('incorrect default symmetry settings')
        covered=set()
        for line in (root/'SHA256SUMS').read_text().splitlines():
            expected,name=line.split('  ',1);relative=Path(name)
            if relative.is_absolute() or '..' in relative.parts:ap.error('invalid manifest path')
            if name not in items or hashlib.sha256(items[name].read_bytes()).hexdigest()!=expected:ap.error('checksum mismatch: '+name)
            covered.add(name)
        if covered!=set(items)-{'SHA256SUMS'}:ap.error('manifest coverage mismatch')
        pairing=json.loads((root/'PAIRING.json').read_text())
        if common_digest(items)!=pairing['common_content_sha256']:ap.error('shared-content fingerprint mismatch')
    print(f'PASS: {len(inventories[0])-2} files are identical; only variant.json and SHA256SUMS differ.')

if __name__=='__main__':main()
