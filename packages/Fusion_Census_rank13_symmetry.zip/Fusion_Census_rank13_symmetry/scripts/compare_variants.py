#!/usr/bin/env python3
"""Run the baseline and symmetry packages sequentially and compare exact data."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    h=hashlib.sha256()
    with gzip.open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def system_digest(root):
    h=hashlib.sha256()
    for path in sorted((root/'systems').rglob('*')):
        if path.is_file():
            h.update(str(path.relative_to(root/'systems')).encode())
            h.update(path.read_bytes())
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,required=True,help='Extracted baseline package directory')
    ap.add_argument('--revised',type=Path,required=True,help='Extracted symmetry package directory')
    ap.add_argument('--rank',type=int,choices=range(3,14),default=11)
    ap.add_argument('--bound',type=int,default=1)
    ap.add_argument('--threads',type=int,default=8)
    ap.add_argument('--out',type=Path,help='Fresh comparison directory')
    ap.add_argument('--order',choices=('baseline-first','revised-first'),default='baseline-first')
    a=ap.parse_args()
    if a.bound<1 or not 1<=a.threads<=64:ap.error('positive bound and threads 1..64 required')
    roots={'baseline':a.baseline.resolve(),'revised':a.revised.resolve()}
    if roots['baseline']==roots['revised']:ap.error('choose two different package directories')
    for name,root in roots.items():
        if not (root/'scripts/run_laptop.py').is_file():ap.error(f'{root}: launcher not found')
        try:configuration=json.loads((root/'variant.json').read_text())
        except (ValueError,OSError) as exc:ap.error(str(exc))
        if not isinstance(configuration,dict) or configuration!={'symmetry_revision':name=='revised'} or type(configuration.get('symmetry_revision')) is not bool:
            ap.error(f'{root}: incorrect variant.json')
    systems={name:system_digest(root) for name,root in roots.items()}
    if systems['baseline']!=systems['revised']:ap.error('the packages contain different equation systems')
    out=(a.out or Path(f'comparison_rank{a.rank}_M{a.bound}')).resolve()
    if out.exists():ap.error('--out must be a fresh directory; preserve earlier results')
    out.mkdir(parents=True)
    report={'rank':a.rank,'bound':a.bound,'threads':a.threads,'order':a.order,
            'complete':False,'systems_sha256':systems['baseline'],'variants':{}}
    try:
        order=('baseline','revised') if a.order=='baseline-first' else ('revised','baseline')
        for name in order:
            folder=out/name
            command=[sys.executable,str(roots[name]/'scripts/run_laptop.py'),
                     '--rank',str(a.rank),'--bound',str(a.bound),'--threads',str(a.threads),
                     '--output-dir',str(folder)]
            console=out/f'{name}.console.log'
            print(f'{name}: running without a clock limit; console: {console}',flush=True)
            print(f'Progress: {folder}/rank{a.rank}_M{a.bound}/run.json',flush=True)
            with console.open('w') as log:
                result=subprocess.run(command,cwd=roots[name],stdout=log,stderr=subprocess.STDOUT)
            state_path=folder/f'rank{a.rank}_M{a.bound}'/'run.json'
            if result.returncode:
                raise RuntimeError(f'{name} returned {result.returncode}; inspect {console}')
            state=json.loads(state_path.read_text())
            if not (state.get('complete') is True and state.get('verified') is True
                    and state.get('symmetry_revision') is (name=='revised')
                    and state.get('rank')==a.rank and state.get('bound')==a.bound
                    and state.get('threads')==a.threads):
                raise ValueError(f'{name}: incomplete result or mismatched settings')
            entry={k:state[k] for k in ('classes','counts','code_sha256','algorithm_sha256',
                    'enumeration_seconds','compilation_seconds','elapsed_seconds')}
            for filename in ('parameters.txt','FusionRingMultiplicationTables.txt'):
                measured=digest(state_path.parent/(filename+'.gz'))
                if measured!=state[filename+'_sha256']:raise ValueError(f'{name}: invalid data hash')
                entry[filename+'_sha256']=measured
            report['variants'][name]=entry
            print(f"{name}: {entry['classes']} rings; enumeration {entry['enumeration_seconds']:.3f}s; compilation {entry['compilation_seconds']:.3f}s",flush=True)
        left,right=(report['variants'][name] for name in ('baseline','revised'))
        for key in ('classes','counts','code_sha256','parameters.txt_sha256','FusionRingMultiplicationTables.txt_sha256'):
            if left[key]!=right[key]:raise ValueError(f'variants disagree: {key}')
        if left['algorithm_sha256']==right['algorithm_sha256']:raise ValueError('same algorithm configuration ran twice')
        report['enumeration_speedup']=left['enumeration_seconds']/right['enumeration_seconds']
        report['exact_data_equal']=True;report['complete']=True
        print(f"EXACT DATA MATCH. Enumeration speedup: {report['enumeration_speedup']:.3f}x",flush=True)
    except KeyboardInterrupt:
        report['error']='comparison interrupted; incomplete results are not certified'
        print(report['error'],file=sys.stderr);return 130
    except (OSError,ValueError,RuntimeError) as exc:
        report['error']=str(exc);print(str(exc),file=sys.stderr);return 1
    finally:
        (out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0


if __name__=='__main__':raise SystemExit(main())
