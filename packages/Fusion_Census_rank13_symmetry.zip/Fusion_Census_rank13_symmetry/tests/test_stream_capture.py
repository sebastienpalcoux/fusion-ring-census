"""Real child processes exercise both output channels and timeout cleanup."""
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('capture_runner',ROOT/'code/run_census.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)

class StreamCaptureTests(unittest.TestCase):
    def test_large_streams_are_complete_and_atomically_published(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'out';log=Path(td)/'log'
            code='import sys;sys.stdout.buffer.write(b"x"*1048613);sys.stderr.buffer.write(b"y"*131103)'
            result=runner.run_enumerator([sys.executable,'-c',code],out,log,env=dict(os.environ),timeout=10)
            self.assertEqual(result.returncode,0)
            self.assertEqual(out.read_bytes(),b'x'*1048613)
            self.assertEqual(log.read_bytes(),b'y'*131103)
            self.assertFalse(list(Path(td).glob('*.next')))

    def test_timeout_closes_streams_and_preserves_only_diagnostics(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'out';log=Path(td)/'log'
            code='import sys,time;print("partial",flush=True);print("incomplete",file=sys.stderr,flush=True);time.sleep(5)'
            with self.assertRaises(subprocess.TimeoutExpired):
                runner.run_enumerator([sys.executable,'-c',code],out,log,env=dict(os.environ),timeout=0.5)
            self.assertEqual(out.read_text(),'partial\n')
            self.assertEqual(log.read_text(),'incomplete\n')
            self.assertFalse(list(Path(td).glob('*.next')))

if __name__=='__main__':unittest.main()
