"""High-rank command routing and independent exact fusion-rule fixtures."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
runner=load('rank13_runner','code/run_census.py')
exporter=load('rank13_exporter','code/export_tables.py')
launcher=load('rank13_launcher','scripts/run_laptop.py')

def check_fixture(test,rank,pairs,tensor):
    name=f'rank{rank}_pairs{pairs}.txt' if pairs else f'system{rank}sd.txt'
    system=json.loads((ROOT/'systems'/f'{name}.json').read_text())
    values=[]
    for orbit in system['orbits']:
        coefficients={tensor[i][j][k] for i,j,k in orbit}
        test.assertEqual(len(coefficients),1)
        values.append(coefficients.pop())
    value=lambda i:values[i] if i>=0 else int(i==-1)
    for equation in system['equations']:
        test.assertEqual(sum(c*value(a)*value(b) for a,b,c in equation),0)
    line=str(pairs)+' '+' '.join(map(str,values))
    test.assertEqual(exporter.tensor(rank,line,ROOT/'systems'),tensor)
    return line

def cyclic(rank):
    pairs=[];fixed=[];seen={0}
    for x in range(1,rank):
        if x in seen:continue
        y=(-x)%rank;seen.update((x,y))
        if x==y:fixed.append(x)
        else:pairs.extend((x,y))
    labels=[0]+pairs+fixed
    return [[[int((labels[i]+labels[j])%rank==labels[k]) for k in range(rank)] for j in range(rank)] for i in range(rank)]

def selfdual(rank):
    if rank==13:
        # The usual truncated sl2 fusion rules at level twelve.
        return [[[int(abs(i-j)<=k<=min(i+j,24-i-j) and (i+j-k)%2==0)
                  for k in range(13)] for j in range(13)] for i in range(13)]
    ising=[[[1,0,0],[0,1,0],[0,0,1]],[[0,1,0],[1,0,0],[0,0,1]],[[0,0,1],[0,0,1],[1,1,0]]]
    return [[[ising[i//4][j//4][k//4]*int((i%4)^(j%4)==k%4)
              for k in range(12)] for j in range(12)] for i in range(12)]

class RankThirteenTests(unittest.TestCase):
    def setUp(self):
        # Numerical mocks remain at the subprocess boundary; stream capture
        # itself is tested separately against real child processes.
        def mocked_capture(cmd,output,logpath,**kwargs):
            with output.open('w') as out,logpath.open('w') as log:
                return runner.subprocess.run(cmd,stdout=out,stderr=log,**kwargs)
        fixture=patch.object(runner,'run_enumerator',side_effect=mocked_capture)
        fixture.start();self.addCleanup(fixture.stop)

    def test_known_rank12_and_13_fusion_rules(self):
        for rank in (12,13):
            with self.subTest(rank=rank,pairs=(rank-1)//2):
                check_fixture(self,rank,(rank-1)//2,cyclic(rank))
            with self.subTest(rank=rank,pairs=0):
                check_fixture(self,rank,0,selfdual(rank))

    def test_all_high_rank_equation_systems_fit_supported_limits(self):
        for rank in (12,13):
            for pairs in range((rank-1)//2+1):
                name=f'rank{rank}_pairs{pairs}.txt' if pairs else f'system{rank}sd.txt'
                data=json.loads((ROOT/'systems'/f'{name}.json').read_text())
                header=list(map(int,(ROOT/'systems'/name).read_text().splitlines()[0].split()))
                self.assertEqual(header,[rank,pairs,len(data['orbits']),len(data['equations']),-1])
                self.assertLessEqual(len(data['orbits']),512)
                self.assertLessEqual(len(data['equations']),8192)
                triples=[tuple(t) for orbit in data['orbits'] for t in orbit]
                self.assertEqual(len(triples),(rank-1)**3)
                self.assertEqual(len(set(triples)),(rank-1)**3)

    def test_both_variants_route_rank12_and_13_to_distinct_builds(self):
        hashes={}
        for rank in (12,13):
            for policy in ('baseline','revised'):
                with self.subTest(rank=rank,policy=policy),tempfile.TemporaryDirectory() as td:
                    commands=[]
                    def fake(cmd,**kw):
                        commands.append(cmd)
                        if '-o' in cmd:
                            Path(cmd[cmd.index('-o')+1]).write_text('mock')
                            return subprocess.CompletedProcess(cmd,0)
                        raise subprocess.TimeoutExpired(cmd,None)
                    args=['driver','--rank',str(rank),'--bound','1','--local-unlimited','--verify',
                          '--symmetry-policy',policy,'--out',td+'/out']
                    with patch.dict(os.environ,{},clear=True),patch.object(sys,'argv',args), \
                         patch.object(runner.subprocess,'run',side_effect=fake), \
                         contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
                        self.assertEqual(runner.main(),3)
                    state=json.loads(Path(td,'out/run.json').read_text())
                    self.assertEqual(state['symmetry_policy'],policy)
                    self.assertEqual(state['symmetry_revision'],policy=='revised')
                    self.assertEqual(state['symmetry_full_group_limit'],8192 if policy=='revised' else 4096)
                    self.assertEqual(state['expected_strata'],[f'pairs{p}' for p in range(1,(rank-1)//2+1)]+['selfdual'])
                    self.assertFalse(state['complete'])
                    for cmd in commands:
                        if '-o' in cmd:
                            self.assertIn('-DCENSUS_SYMMETRY_REVISION='+str(int(policy=='revised')),cmd)
                            self.assertTrue(cmd[cmd.index('-o')+1].endswith('_'+policy))
                    hashes[rank,policy]=(state['code_sha256'],state['algorithm_sha256'])
            self.assertEqual(hashes[rank,'baseline'][0],hashes[rank,'revised'][0])
            self.assertNotEqual(hashes[rank,'baseline'][1],hashes[rank,'revised'][1])

    def test_wrong_variant_cannot_be_packaged(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)
            (out/'run.json').write_text(json.dumps({'symmetry_revision':False}))
            with self.assertRaisesRegex(ValueError,'symmetry variant'):
                launcher.package_result(out,out/'result.zip',13,1,None,expected_revision=True)

if __name__=='__main__':unittest.main()
