# Fusion-ring census through rank 13: symmetry comparison (v4)

The two standalone packages contain identical source code, equation systems,
tests and documentation. Their only setting difference is `variant.json`:

- **baseline**: the existing symmetry policy, extended through rank 13;
- **symmetry**: watched symmetry-domain propagation and a larger bounded table
  of symmetry comparisons.

The launcher prints the selected policy. Both packages enumerate general fusion
rings, including all duality types and noncommutative rings. They generate rings
from exact equations, without downloading or importing AnyonWiki/AnyonAtlas data.
Recorded results are used only for verification and regression tests.

## Install and run one version

On Ubuntu, dependencies are Python 3.9+ and GNU g++ with C++17/OpenMP:

```bash
sudo apt-get install python3 g++ unzip
```

Extract each ZIP into a fresh directory. From inside either extracted package:

```bash
python3 scripts/run_laptop.py --rank 13 --bound 1 --threads 8
```

Supported bounds are 1–1000 for ranks 3–4, 1–32 for rank 5, and 1–15 for ranks
6–13. These are arithmetic/input limits, not promises of feasible runtime or
memory at every bound. Start high-rank comparisons at bound 1.

The first run compiles automatically; later runs reuse matching binaries.
Rank-specific compilation and dependency checks are retained. Binary cache keys
include the symmetry policy, so a baseline executable cannot be reused as a
revised executable.

The laptop command has no clock limit. Keep the machine awake. Interruption
cannot resume an unfinished search: preserve its diagnostics and select a fresh
`--output-dir` for a new run.

## Compare the two versions on the same laptop

Place the two extracted directories next to each other, then run this from
their parent directory:

```bash
python3 Fusion_Census_rank13_baseline/scripts/compare_variants.py \
  --baseline Fusion_Census_rank13_baseline \
  --revised Fusion_Census_rank13_symmetry \
  --rank 11 --bound 1 --threads 8
```

The script runs the two searches **sequentially**, with the same inputs and
thread count. It records compilation time separately from enumeration time.
It then compares the complete sorted parameters and multiplication tensors by
SHA-256, verifies the common source hash, and checks that opposite symmetry
settings actually ran. The report is `comparison_rank11_M1/comparison.json`.
Each version also produces its own verified result ZIP in that directory.

To compare rank 12 or 13, change `--rank`. To repeat a comparison, give a fresh
`--out`, for example `--out repeat_rank11`, and optionally use
`--order revised-first`. Avoid other heavy workloads during a timing comparison.
The symmetry revision is experimental: additional pruning can also introduce
overhead, so a speedup is not assumed.

## Results and integrity

For a standalone rank-13/bound-1 run, results are under `runs/rank13_M1/`, and
its final archive is `runs/rank13_multiplicity1_verified.zip`. The archive is
created only after every duality type finishes, engine totals match emitted
records, exact tensor checks pass, no isomorphic duplicates remain, and every
available certified reference-count prefix agrees.

Ranks 3–8 keep their existing mandatory count-prefix check. Ranks 9–13 do not
silently acquire a new reference baseline from a computation. The provenance
records an absent baseline explicitly. The supplied completed rank-11 data
(182 rings, approximately one hour on the user's laptop) is a regression fixture;
it is not read by the enumerators to generate solutions.

Child output and error streams are drained to disk and atomically published.
Timeouts and incomplete/truncated data cannot produce a certified archive.
`run.json` records the symmetry policy, shared source hash and distinct algorithm
configuration hash. `SHA256SUMS` covers the distribution files.

## Checks and limitations

The complete lower-rank output comparisons, high-rank fixtures, arithmetic checks
and measured timings are documented in `VALIDATION_V4.md`. A completed rank-12 or
rank-13 census is not supplied or claimed. The exact first-matrix and full-ring
canonicality checks remain in both versions.

Run the Python checks and new C++ audits:

```bash
python3 -m unittest discover -s tests -v
python3 audits/run_rank13_audits.py
python3 audits/run_rank13_audits.py --references
```

The mathematical argument for the revision and the rank-13 arithmetic bounds is
`methods/RANK13_SYMMETRY_COMPARISON.md`. Earlier proofs and benchmark evidence
are retained for provenance. `SOURCE.json` records the input archive and shared
source inventory. This delivery does not modify or publish a GitHub repository.
